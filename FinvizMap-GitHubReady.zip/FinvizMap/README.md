# FinvizMap

Minimal Android app that opens the Finviz market map inside a WebView.

## Automatic APK build on GitHub

The repository contains `.github/workflows/build-apk.yml`.
Every push to `main` triggers a build automatically.

To download the APK:
1. Open the repository on GitHub.
2. Open **Actions**.
3. Open the latest **Build FinvizMap APK** run.
4. At the bottom, under **Artifacts**, download **FinvizMap-APK**.
5. Extract the ZIP and install `FinvizMap.apk` on Android.

You can also open **Actions → Build FinvizMap APK → Run workflow** to build manually.
